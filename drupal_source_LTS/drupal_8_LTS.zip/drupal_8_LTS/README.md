<img alt="Drupal Logo" src="https://www.drupal.org/files/Wordmark_blue_RGB.png" height="60px">

# Projets et dossiers disponibles

| Dossier | Version | Technologies | Langages | Pré-requis | Identifiants | Init | Build | Backup |
|---|---|---|---|---|---|---|---|---|
| /datas | - | SQLite | SQL | SQLiteStudio | - | - | - | - |
| /docker | - | docker | Docker | - | - | - | - | - |
| /drupal_8| 8.9.7 | Php/Symfony | Php 7.x | >= Php 7.4 (avec OPCache) | drupal - Drupal8 | ❌ | ✅ | ❌ |
| /drupal_8_ens | 8.9.7  | Php/Symfony | Php 7.x | >= Php 7.4 (avec OPCache) | drupal - Drupal8 | ✅ | ❌ | ✅ |
| /drupal_9 | 9.4.9 | Php/Symfony | Php 8.x | >= Php 7.4 (avec OPCache) | drupal - Drupal8 | ❌ | ✅ | ❌ |
| /drupal_10 | 10.0.x-dev | Php/Symfony | Php 8.x | >= Php 8.1.0 (avec OPCache) | drupal - Drupal8 | ❌ | ✅ | ❌ |
| /modules | - | Php/Symfony | Php 7.x | - | - | - | - | - |

# Démarrage d'un projet

Il est possible de démarrrer une projet avec la commande ci-dessous dans le dossier dauns projet.

```
php -S localhost:8005
```

# Guides et dépannages

- [DRUPAL_DOCS](DRUPAL_DOCS.md)
- [DRUPAL_DEBUG](DRUPAL_DEBUG.md)